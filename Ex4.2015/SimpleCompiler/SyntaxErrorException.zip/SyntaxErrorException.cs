﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleCompiler
{
    public class SyntaxErrorException : Exception
    {
        public SyntaxErrorException(string sMsg)
            : base(sMsg)
        {
        }
    }
}
